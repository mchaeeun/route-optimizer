#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <iostream>
#include <fstream>
#include <queue>
#include <set>

using namespace std;

struct Coord3D
{
    double x, y, z;
    Coord3D(double x, double y, double z) : x(x), y(y), z(z){};
};

struct Vertex
{
    int id;
    string name;
    Coord3D coord;
};

struct Edge
{
    int vid1, vid2;
    double cost;
};

struct Graph
{
    vector<Vertex> vertices;
    vector<vector<Edge>> edges;

    void addVertex(string name, Coord3D coord);
    void addEdge(int vid1, int vid2, double cost);
    vector<int> getNeighbors(int vid);
    int getCost(int vid1, int vid2);
};

void Graph::addVertex(string name, Coord3D coord)
{
    int new_id = vertices.size();
    Vertex v = {new_id, name, coord};
    vector<Edge> e;
    vertices.push_back(v);
    edges.push_back(e);
}

void Graph::addEdge(int vid1, int vid2, double cost)
{
    Edge e1 = {vid1, vid2, cost};
    Edge e2 = {vid2, vid1, cost};
    edges[vid1].push_back(e1);
    edges[vid2].push_back(e2);
}

vector<int> Graph::getNeighbors(int vid)
{
    vector<int> neighbors;
    for (Edge e : edges[vid])
        neighbors.push_back(e.vid2);
    return neighbors;
}

int Graph::getCost(int vid1, int vid2)
{
    for (Edge e : edges[vid1])
        if (e.vid2 == vid2)
            return e.cost;
    return -1; // failure
}

class A_star
{
private:
    Graph g;
    int sid;
    int gid;

    double heuristic(int current);
    void reconstruct_path(int came_from[], int current);

public:
    deque<int> path;
    A_star(Graph g, int sid, int gid);
    void print_path();
};

double A_star::heuristic(int current)
{
    Coord3D scoord = g.vertices[current].coord;
    Coord3D gcoord = g.vertices[gid].coord;
    return abs(scoord.x - gcoord.x) + abs(scoord.y - gcoord.y) + abs(scoord.z - gcoord.z);
}

void A_star::reconstruct_path(int came_from[], int current)
{
    path.push_back(current);
    int pid = current;
    while (came_from[pid] != -1)
    {
        pid = came_from[pid];
        path.push_front(pid);
    }
}

A_star::A_star(Graph g, int sid, int gid) : g(g), sid(sid), gid(gid)
{
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> open_queue;
    set<int> open_set;
    open_queue.push(pair<int, int>(0, sid));
    open_set.insert(sid);

    const int vertices_count = g.vertices.size();
    int came_from[vertices_count];
    for (int i = 0; i < vertices_count; ++i)
        came_from[i] = -1;

    double g_score[vertices_count];
    for (int i = 0; i < vertices_count; ++i)
        g_score[i] = MAXFLOAT;
    g_score[sid] = 0;

    double f_score[vertices_count];
    for (int i = 0; i < vertices_count; ++i)
        f_score[i] = MAXFLOAT;
    f_score[sid] = heuristic(sid);

    while (!open_set.empty())
    {
        int current = open_queue.top().second;
        if (current == gid)
            reconstruct_path(came_from, current);

        open_queue.pop();
        open_set.erase(current);
        vector<int> current_neighbors = g.getNeighbors(current);
        for (int neighbor : current_neighbors)
        {
            double tentative_g_score = g_score[current] + g.getCost(current, neighbor);
            if (tentative_g_score < g_score[neighbor])
            {
                came_from[neighbor] = current;
                g_score[neighbor] = tentative_g_score;
                f_score[neighbor] = tentative_g_score + heuristic(neighbor);
                if (open_set.find(neighbor) == open_set.end())
                {
                    open_queue.push(pair<int, int>(f_score[neighbor], neighbor));
                    open_set.insert(neighbor);
                }
            }
        }
    }
}

void A_star::print_path()
{
    cout << "path: " << endl;
    for (int i = 0; i < path.size(); ++i)
        cout << g.vertices[path[i]].name << endl;
}

int main()
{
    ifstream fs;
    Graph g;

    fs.open("astar_node.csv", ios::in);
    while (!fs.eof())
    {
        string name;
        string sx, sy, sz, ix, iy;
        double x, y, z;

        getline(fs, name, ',');
        if (fs.eof())
            break;
        getline(fs, sx, ',');
        getline(fs, sy, ',');
        getline(fs, sz, ',');
        getline(fs, ix, ',');
        fs >> iy;

        x = stod(sx);
        y = stod(sy);
        z = stod(sz);
        g.addVertex(name, Coord3D(x, y, z));
        fs.ignore();
    }
    fs.close();

    fs.open("edges.csv", ios::in);
    while (!fs.eof())
    {
        string svid1, svid2, scost;
        int vid1, vid2;
        double cost;

        getline(fs, svid1, ',');
        if (fs.eof())
            break;
        for (Vertex v : g.vertices)
        {
            if (v.name == svid1)
            {
                vid1 = v.id;
                break;
            }
        }

        getline(fs, svid2, ',');
        for (Vertex v : g.vertices)
        {
            if (v.name == svid2)
            {
                vid2 = v.id;
                break;
            }
        }
        fs >> scost;
        cost = stod(scost);
        g.addEdge(vid1, vid2, cost);
        fs.ignore();
    }

    string start, end;
    int startid = -1, endid = -1;
    cout << "출발 강의실을 입력하세요 (ex 원흥관 314): ";
    getline(cin, start);
    for (Vertex v : g.vertices)
        if (v.name == start)
        {
            startid = v.id;
            break;
        }
    if (startid == -1)
    {
        cout << "데이터에 존재하지 않는 강의실입니다." << endl;
        return -1;
    }

    cout << "도착 강의실을 입력하세요 (ex 신공학관 6119): ";
    getline(cin, end);
    for (Vertex v : g.vertices)
        if (v.name == end)
        {
            endid = v.id;
            break;
        }
    if (endid == -1)
    {
        cout << "데이터에 존재하지 않는 강의실입니다." << endl;
        return -1;
    }

    A_star a(g, startid, endid);
    cout << "from: " << g.vertices[startid].name << ", to: " << g.vertices[endid].name << endl;
    a.print_path();

    return 0;
}
